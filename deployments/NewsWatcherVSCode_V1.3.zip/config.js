var config = {};
config.JWT_SECERET = "My First JWT";
config.NEWYORKTIMES_API_KEY = "a3419de901e045719d739fe62e7063cd";
config.NEWYORKTIMES_CATEGORIES = ["world","national","business"];
config.GLOBAL_STORIES_ID = "MASTER_STORIES_DO_NOT_DELETE";
config.MAX_SHARED_STORIES = 30;
config.MAX_FILTERS = 5;
config.MAX_COMMENTS = 30;
config.MAX_FILTER_STORIES = 15;
config.MONGODB_CONNECT_URL = "mongodb://sandeep:Arun123@ds135983.mlab.com:35983/newswatcherdb"

module.exports = config;
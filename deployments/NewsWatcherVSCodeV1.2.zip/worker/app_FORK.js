"use strict"
var config = require('../config');
var bcrypt = require('bcryptjs');
var http = require("http");
var async = require('async');
var assert = require('assert');
var ObjectId = require('mongodb').ObjectID;
var mongoClient = require('mongodb').MongoClient;

var db ={};
mongoClient.connect(config.MONGODB_CONNECT_URL,function(err,dbConn){
    assert.equal(null,err);
    db.collection = dbConn;
    console.log("Connected to  MongoDbServer");
});

process.on('message',function(m){
    if (m.msg){
        if (m.msg == 'REFRESH_STORIES'){
            setImmediate(function(doc){
                refreshStoriesMSG(doc,null,null);
            },m.doc);
        }
    }else{
        console.log("Message from Master: ",m);
    }
});

function refreshStoriesMSG(doc,globalNewsDoc,callback){
    if (!globalNewsDoc){
        db.collection.findOne({_id:config.GLOBAL_STORIES_ID},function(err,gDoc){
            if (err){
                console.log('Fork_Error:global news read error',+err);
                if (callback)
                    return callback(err);
                else return;
            }
            else{
                refreshStories(doc,gDoc,callback);
            }
        });
    }
    else{
        refreshStories(doc,globalNewsDoc,callback);
    }
}

function refreshStories(doc,globalNewsDoc,callback){
    for (var filterIdx = 0;filterIdx<doc.newsFilters.length;filterIdx++){
        doc.newsFilters[filterIdx].newsStories = [];
        for (var i=0;i<globalNewsDoc.newsStories.length;i++){
            globalNewsDoc.newsStories[i].keep = false;
        }
        if ("keyWords" in doc.newsFilters[filterIdx] && doc.newsFilters[filterIdx].keyWords[0] != ""){
            var storiesMatched = 0;
            for (var i =0;i<doc.newsFilters[filterIdx].keyWords.length;i++){
                for(var j=0;j<globalNewsDoc.newsStories.length;j++){
                    if (globalNewsDoc.newsStories[i].keep == false){
                        var s1 = globalNewsDoc.newsStories[j].title.toLowerCase();
                        var s2 = globalNewsDoc.newsStories[j].contentSnippet.toLowerCase();
                        var keyWord = doc.newsFilters[filterIdx].keyWords[i].toLowerCase();
                        if (s1.indexOf(keyWord)>=0 || s2.indexOf(keyWord)>=0){
                            globalNewsDoc.newsStories[j].keep = true;
                            storiesMatched++;
                        }
                    }
                    if (storiesMatched == config.MAX_FILTER_STORIES)
                        break;
                }
                if (storiesMatched == config.MAX_FILTER_STORIES)
                    break;
            }
            for (var k=0;k<globalNewsDoc.newsStories.length;k++){
                if (globalNewsDoc.newsStories[k].keep == true){
                    doc.newsFilters[filterIdx].newsFilters.push(globalNewsDoc.newsStories[k]);
                }
            }
        }
    }
    if (doc.newsFilters.length == 1 && doc.newsFilters[0].keyWords.length == 1 && doc.newsFilters[0].keyWords[0]
        === "testingkeyword"){
            for (var i=0;i<5;i++){
                doc.newsFilters[0].newsStories.push(globalNewsDoc.newsStories[0]);
                doc.newsFilters[0].newsStories[0].title = "testingkeyword tittle"+i;
            }
        }
        
        db.collection.findOneAndUpdate({
            _id : ObjectId(doc._id)
        },{$set:{"newsFilters":doc.newsFilters}},function(err,result){
            if (err){
                console.log("Fork_error replace of newstories failed",err);
            }else if(result.ok!=1){
                console.log("Fork_error Replace of new stories failed",result);
            }else{
                if(doc.newsFilters.length > 0){
                    console.log({
                        msg : 'MasterNews_update first filter news  length='+doc.newsFilters[0].newsStories.length
                    });
                }else{
                    console.log({
                        msg : 'MasterNews_Update NO NewsFilters'
                    });
                }
            }
            if (callback)
                return callback(err);
        });
    
}
